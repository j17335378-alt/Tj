(() => {
  "use strict";

  const DB_NAME = "tikjil-private";
  const STORE = "files";
  const KEY = "tikjil-lib-v1";
  const SAMPLE_YT = "https://youtu.be/r66V1h52F78";

  /** @typedef {{id:string,title:string,sourceUrl:string,kind:'youtube'|'tiktok'|'vimeo'|'instagram'|'remote'|'local'|'link',platform:string,platformId?:string,author?:string,thumbnail?:string,sizeBytes:number,addedAt:string,liked:boolean,views:number}} VideoItem */
  /** @typedef {{id:string,kind:string,title:string,body:string,createdAt:string,read:boolean,videoId?:string}} InboxMsg */

  const state = {
    tab: "home",
    items: /** @type {VideoItem[]} */ ([]),
    inbox: /** @type {InboxMsg[]} */ ([]),
    profile: { name: "أنا", bio: "مكتبتي الخاصة على TikJil", color: 0 },
    settings: { layout: "list", loop: true, muted: true },
    seeded: false,
    watchCount: 0,
    playingId: null,
    busy: false,
  };

  const view = document.getElementById("view");
  const playerEl = document.getElementById("player");
  const toastEl = document.getElementById("toast");
  const badgeEl = document.getElementById("badge");
  const offlineEl = document.getElementById("offline");

  // ─── storage ───────────────────────────────────────────────
  function load() {
    try {
      const raw = localStorage.getItem(KEY);
      if (!raw) return;
      const data = JSON.parse(raw);
      state.items = Array.isArray(data.items) ? data.items : [];
      state.inbox = Array.isArray(data.inbox) ? data.inbox : [];
      state.profile = data.profile || state.profile;
      state.settings = { ...state.settings, ...(data.settings || {}) };
      state.seeded = !!data.seeded;
      state.watchCount = data.watchCount || 0;
    } catch {
      /* ignore corrupt */
    }
  }

  function save() {
    localStorage.setItem(
      KEY,
      JSON.stringify({
        items: state.items,
        inbox: state.inbox,
        profile: state.profile,
        settings: state.settings,
        seeded: state.seeded,
        watchCount: state.watchCount,
      }),
    );
  }

  function ensureSeed() {
    if (state.seeded) return;
    state.seeded = true;
    const now = new Date().toISOString();
    state.inbox = [
      {
        id: "seed-copy",
        kind: "tip",
        title: "حقوق النشر والاستخدام الخاص",
        body: "TikJil تطبيق خاص بك فقط. يحفظ الروابط والبيانات للمشاهدة الشخصية عبر المشغّلات الرسمية (يوتيوب، تيك توك، فيميو…). لا يستخرج ملفات المواقع المحمية ولا ينشر محتواك.",
        createdAt: now,
        read: false,
      },
      {
        id: "seed-yt",
        kind: "tip",
        title: "مواقع مثل يوتيوب",
        body: "الصق الرابط في «استرداد». المقطع يُحفظ في مكتبتك ويُشغَّل من هنا. الملف نفسه يبقى عند المنصة لأن الحماية لا تُتجاوز.",
        createdAt: now,
        read: false,
      },
      {
        id: "seed-welcome",
        kind: "welcome",
        title: "مرحبًا في TikJil",
        body: "استورد من جهازك، أو الصق رابطًا مباشرًا (mp4)، أو احفظ مقاطع المنصات في مكتبتك للتشغيل السريع.",
        createdAt: now,
        read: false,
      },
    ];
    save();
  }

  function openDb() {
    return new Promise((resolve, reject) => {
      const req = indexedDB.open(DB_NAME, 1);
      req.onupgradeneeded = () => {
        if (!req.result.objectStoreNames.contains(STORE)) req.result.createObjectStore(STORE);
      };
      req.onsuccess = () => resolve(req.result);
      req.onerror = () => reject(req.error || new Error("تعذّر فتح التخزين"));
    });
  }

  async function idbPut(id, blob) {
    const db = await openDb();
    await new Promise((resolve, reject) => {
      const tx = db.transaction(STORE, "readwrite");
      tx.objectStore(STORE).put(blob, id);
      tx.oncomplete = () => resolve();
      tx.onerror = () => reject(tx.error);
    });
    db.close();
  }

  async function idbGet(id) {
    const db = await openDb();
    const blob = await new Promise((resolve, reject) => {
      const tx = db.transaction(STORE, "readonly");
      const req = tx.objectStore(STORE).get(id);
      req.onsuccess = () => resolve(req.result instanceof Blob ? req.result : null);
      req.onerror = () => reject(req.error);
    });
    db.close();
    return blob;
  }

  async function idbDel(id) {
    const db = await openDb();
    await new Promise((resolve, reject) => {
      const tx = db.transaction(STORE, "readwrite");
      tx.objectStore(STORE).delete(id);
      tx.oncomplete = () => resolve();
      tx.onerror = () => reject(tx.error);
    });
    db.close();
  }

  // ─── helpers ───────────────────────────────────────────────
  function uid() {
    return crypto.randomUUID ? crypto.randomUUID() : String(Date.now()) + Math.random().toString(16).slice(2);
  }

  function formatBytes(n) {
    if (!n || n <= 0) return "0 B";
    if (n < 1024) return `${Math.round(n)} B`;
    if (n < 1024 * 1024) return `${Math.round(n / 1024)} KB`;
    return `${(n / (1024 * 1024)).toFixed(1)} MB`;
  }

  function formatTime(sec) {
    if (!Number.isFinite(sec) || sec < 0) return "0:00";
    const s = Math.floor(sec % 60);
    const m = Math.floor((sec / 60) % 60);
    const h = Math.floor(sec / 3600);
    if (h > 0) return `${h}:${String(m).padStart(2, "0")}:${String(s).padStart(2, "0")}`;
    return `${m}:${String(s).padStart(2, "0")}`;
  }

  function toast(msg) {
    toastEl.textContent = msg;
    toastEl.classList.remove("hidden");
    clearTimeout(toast._t);
    toast._t = setTimeout(() => toastEl.classList.add("hidden"), 2800);
  }

  function flashSeek(stage, delta) {
    let el = stage.querySelector(".seek-flash");
    if (!el) {
      el = document.createElement("div");
      el.className = "seek-flash";
      stage.appendChild(el);
    }
    el.textContent = delta > 0 ? `+${delta} ث` : `${delta} ث`;
    el.classList.remove("show");
    // force reflow
    void el.offsetWidth;
    el.classList.add("show");
    clearTimeout(el._t);
    el._t = setTimeout(() => el.classList.remove("show"), 700);
  }

  /**
   * Attach double-tap seek (±10s) + draggable progress bar to a native <video>.
   * Does not apply to iframe embeds (YouTube/TikTok/Vimeo).
   */
  function wireNativeVideoControls(video, stage) {
    if (!video || !stage) return;

    // Overlay zones + custom scrubber
    const overlay = document.createElement("div");
    overlay.className = "seek-overlay";
    overlay.innerHTML = `
      <div class="seek-zone seek-left" data-seek="-10" aria-label="ترجيع 10 ثوانٍ"></div>
      <div class="seek-zone seek-right" data-seek="10" aria-label="تقديم 10 ثوانٍ"></div>
    `;
    stage.appendChild(overlay);

    const bar = document.createElement("div");
    bar.className = "custom-controls";
    bar.innerHTML = `
      <div class="time-row">
        <span class="cur-time">0:00</span>
        <div class="scrubber" role="slider" aria-label="شريط التقدم" tabindex="0">
          <div class="scrub-track">
            <i class="scrub-fill"></i>
            <div class="scrub-thumb"></div>
          </div>
        </div>
        <span class="dur-time">0:00</span>
      </div>
    `;
    stage.appendChild(bar);

    const curEl = bar.querySelector(".cur-time");
    const durEl = bar.querySelector(".dur-time");
    const fill = bar.querySelector(".scrub-fill");
    const thumb = bar.querySelector(".scrub-thumb");
    const scrubber = bar.querySelector(".scrubber");
    const track = bar.querySelector(".scrub-track");

    let dragging = false;

    function updateUI() {
      const dur = video.duration || 0;
      const cur = video.currentTime || 0;
      const pct = dur > 0 ? Math.min(100, Math.max(0, (cur / dur) * 100)) : 0;
      if (curEl) curEl.textContent = formatTime(cur);
      if (durEl) durEl.textContent = formatTime(dur);
      if (fill) fill.style.width = `${pct}%`;
      if (thumb) thumb.style.left = `${pct}%`;
    }

    video.addEventListener("timeupdate", updateUI);
    video.addEventListener("loadedmetadata", updateUI);
    video.addEventListener("durationchange", updateUI);
    video.addEventListener("seeked", updateUI);

    // Double-tap left/right
    let lastTap = { t: 0, side: null };
    const TAP_MS = 320;

    overlay.querySelectorAll(".seek-zone").forEach((zone) => {
      zone.addEventListener("click", (e) => {
        e.preventDefault();
        e.stopPropagation();
        const side = zone.classList.contains("seek-left") ? "left" : "right";
        const now = Date.now();
        if (lastTap.side === side && now - lastTap.t < TAP_MS) {
          const delta = side === "left" ? -10 : 10;
          const next = Math.max(0, Math.min((video.duration || 0), (video.currentTime || 0) + delta));
          video.currentTime = next;
          flashSeek(stage, delta);
          updateUI();
          lastTap = { t: 0, side: null };
        } else {
          lastTap = { t: now, side };
        }
      });
    });

    // Scrub / drag progress
    function seekFromClientX(clientX) {
      const rect = track.getBoundingClientRect();
      if (!rect.width || !video.duration) return;
      // RTL: still use left-to-right percentage based on visual left
      let ratio = (clientX - rect.left) / rect.width;
      ratio = Math.max(0, Math.min(1, ratio));
      video.currentTime = ratio * video.duration;
      updateUI();
    }

    function onPointerDown(e) {
      if (!video.duration) return;
      dragging = true;
      scrubber.classList.add("dragging");
      scrubber.setPointerCapture?.(e.pointerId);
      seekFromClientX(e.clientX);
      e.preventDefault();
    }
    function onPointerMove(e) {
      if (!dragging) return;
      seekFromClientX(e.clientX);
    }
    function onPointerUp(e) {
      if (!dragging) return;
      dragging = false;
      scrubber.classList.remove("dragging");
      try {
        scrubber.releasePointerCapture?.(e.pointerId);
      } catch {
        /* ignore */
      }
    }

    scrubber.addEventListener("pointerdown", onPointerDown);
    scrubber.addEventListener("pointermove", onPointerMove);
    scrubber.addEventListener("pointerup", onPointerUp);
    scrubber.addEventListener("pointercancel", onPointerUp);

    // Keyboard: arrows when scrubber focused
    scrubber.addEventListener("keydown", (e) => {
      if (!video.duration) return;
      if (e.key === "ArrowLeft" || e.key === "ArrowRight") {
        e.preventDefault();
        const delta = e.key === "ArrowLeft" ? -10 : 10;
        video.currentTime = Math.max(0, Math.min(video.duration, video.currentTime + delta));
        flashSeek(stage, delta);
        updateUI();
      }
    });

    // Hide native controls so custom UI is primary (still accessible via long-press on some browsers)
    video.controls = false;
    updateUI();
  }

  function pushInbox(kind, title, body, videoId) {
    state.inbox.unshift({
      id: uid(),
      kind,
      title,
      body,
      createdAt: new Date().toISOString(),
      read: false,
      videoId,
    });
    state.inbox = state.inbox.slice(0, 80);
    save();
    updateBadge();
  }

  function updateBadge() {
    const n = state.inbox.filter((m) => !m.read).length;
    if (n > 0) {
      badgeEl.textContent = String(n);
      badgeEl.classList.remove("hidden");
    } else {
      badgeEl.classList.add("hidden");
    }
  }

  function markIcon(lg) {
    return `<span class="mark ${lg ? "lg" : ""}" aria-hidden="true"><svg viewBox="0 0 24 24"><path d="M8 5.5v13l11-6.5L8 5.5z"/></svg></span>`;
  }

  function escapeHtml(s) {
    const d = document.createElement("div");
    d.textContent = String(s);
    return d.innerHTML;
  }

  // ─── platform detection ────────────────────────────────────
  function parsePlatform(raw) {
    let url;
    try {
      const t = raw.trim();
      url = new URL(/^https?:\/\//i.test(t) ? t : `https://${t}`);
    } catch {
      return null;
    }
    const host = url.hostname.replace(/^www\./, "").replace(/^m\./, "").toLowerCase();
    const path = url.pathname;

    // YouTube
    if (host === "youtu.be") {
      const id = path.split("/").filter(Boolean)[0];
      if (id && /^[\w-]{11}$/.test(id)) return { platform: "youtube", id, pageUrl: `https://youtu.be/${id}`, kind: "youtube" };
    }
    if (host === "youtube.com" || host === "youtube-nocookie.com" || host === "music.youtube.com") {
      let id = url.searchParams.get("v");
      const parts = path.split("/").filter(Boolean);
      if (!id && (parts[0] === "shorts" || parts[0] === "embed" || parts[0] === "live" || parts[0] === "v") && parts[1]) {
        id = parts[1];
      }
      if (id && /^[\w-]{11}$/.test(id)) return { platform: "youtube", id, pageUrl: `https://youtu.be/${id}`, kind: "youtube" };
      return { platform: "youtube", id: null, pageUrl: url.toString(), kind: "link", note: "رابط يوتيوب بدون مقطع محدد. الصق رابط المقطع نفسه." };
    }

    // TikTok
    if (host === "tiktok.com" || host.endsWith(".tiktok.com") || host === "vm.tiktok.com" || host === "vt.tiktok.com") {
      const m = path.match(/\/video\/(\d+)/) || path.match(/\/@[^/]+\/video\/(\d+)/);
      if (m) return { platform: "tiktok", id: m[1], pageUrl: url.toString(), kind: "tiktok" };
      return { platform: "tiktok", id: null, pageUrl: url.toString(), kind: "link", note: "افتح رابط المقطع المباشر من تيك توك ثم الصقه." };
    }

    // Vimeo
    if (host === "vimeo.com" || host.endsWith(".vimeo.com")) {
      const m = path.match(/\/(\d{6,})/);
      if (m) return { platform: "vimeo", id: m[1], pageUrl: url.toString(), kind: "vimeo" };
    }

    // Instagram
    if (host === "instagram.com" || host.endsWith(".instagram.com")) {
      const m = path.match(/\/(reel|p|tv)\/([^/]+)/);
      if (m) return { platform: "instagram", id: m[2], pageUrl: url.toString(), kind: "instagram" };
      return { platform: "instagram", id: null, pageUrl: url.toString(), kind: "link", note: "الصق رابط الريل أو المنشور." };
    }

    // Direct media and HLS playlists
    if (/\.m3u8(\?|#|$)/i.test(url.pathname + url.search)) {
      return { platform: "hls", id: null, pageUrl: url.toString(), kind: "remote" };
    }
    if (/\.(mp4|webm|mov|m4v|mkv|3gp)(\?|#|$)/i.test(url.pathname + url.search)) {
      return { platform: "file", id: null, pageUrl: url.toString(), kind: "remote" };
    }

    return { platform: "web", id: null, pageUrl: url.toString(), kind: "link" };
  }

  async function resolveMeta(parsed) {
    const base = {
      title: "مقطع",
      author: "",
      thumbnail: "",
    };

    if (parsed.platform === "youtube" && parsed.id) {
      base.thumbnail = `https://i.ytimg.com/vi/${parsed.id}/hqdefault.jpg`;
      base.title = "فيديو يوتيوب";
      try {
        const r = await fetch(
          `https://www.youtube.com/oembed?format=json&url=${encodeURIComponent(parsed.pageUrl)}`,
        );
        if (r.ok) {
          const j = await r.json();
          if (j.title) base.title = String(j.title).slice(0, 140);
          if (j.author_name) base.author = String(j.author_name).slice(0, 80);
          if (j.thumbnail_url) base.thumbnail = j.thumbnail_url;
        }
      } catch {
        /* offline / blocked */
      }
      return base;
    }

    if (parsed.platform === "tiktok" && parsed.id) {
      base.title = "مقطع تيك توك";
      try {
        const r = await fetch(`https://www.tiktok.com/oembed?url=${encodeURIComponent(parsed.pageUrl)}`);
        if (r.ok) {
          const j = await r.json();
          if (j.title) base.title = String(j.title).slice(0, 140);
          if (j.author_name) base.author = String(j.author_name).slice(0, 80);
          if (j.thumbnail_url) base.thumbnail = j.thumbnail_url;
        }
      } catch {
        /* */
      }
      return base;
    }

    if (parsed.platform === "vimeo" && parsed.id) {
      base.title = "فيديو Vimeo";
      try {
        const r = await fetch(`https://vimeo.com/api/oembed.json?url=${encodeURIComponent(parsed.pageUrl)}`);
        if (r.ok) {
          const j = await r.json();
          if (j.title) base.title = String(j.title).slice(0, 140);
          if (j.author_name) base.author = String(j.author_name).slice(0, 80);
          if (j.thumbnail_url) base.thumbnail = j.thumbnail_url;
        }
      } catch {
        /* */
      }
      return base;
    }

    if (parsed.platform === "instagram") {
      base.title = "منشور إنستغرام";
      base.author = "Instagram";
      return base;
    }

    if (parsed.kind === "remote") {
      const name = parsed.pageUrl.split("/").pop()?.split("?")[0] || "فيديو";
      base.title = decodeURIComponent(name).replace(/\.[a-z0-9]+$/i, "").replace(/[_-]+/g, " ") || "فيديو مباشر";
      return base;
    }

    base.title = parsed.pageUrl;
    return base;
  }

  function embedUrl(item) {
    if (item.kind === "youtube" && item.platformId) {
      return `https://www.youtube-nocookie.com/embed/${item.platformId}?rel=0&modestbranding=1&playsinline=1&autoplay=1`;
    }
    if (item.kind === "tiktok" && item.platformId) {
      return `https://www.tiktok.com/embed/v2/${item.platformId}`;
    }
    if (item.kind === "vimeo" && item.platformId) {
      return `https://player.vimeo.com/video/${item.platformId}?autoplay=1`;
    }
    return null;
  }

  function platformLabel(item) {
    if (item.platform === "hls") return "فيديو HLS";
    const map = {
      youtube: "يوتيوب",
      tiktok: "تيك توك",
      vimeo: "Vimeo",
      instagram: "إنستغرام",
      remote: "رابط مباشر",
      local: "من الجهاز",
      link: "رابط",
    };
    return map[item.kind] || item.platform || "مقطع";
  }

  // ─── library ops ───────────────────────────────────────────
  function findBySource(url) {
    return state.items.find((i) => i.sourceUrl === url);
  }

  function addItem(item) {
    state.items = [item, ...state.items.filter((i) => i.id !== item.id && i.sourceUrl !== item.sourceUrl)];
    save();
  }

  async function savePlatformClip(parsed, meta) {
    if (!parsed.id && parsed.kind !== "instagram" && parsed.kind !== "link") {
      throw new Error(parsed.note || "الرابط غير مكتمل.");
    }
    const existing = findBySource(parsed.pageUrl);
    if (existing) return existing;

    const kind =
      parsed.kind === "youtube" || parsed.kind === "tiktok" || parsed.kind === "vimeo" || parsed.kind === "instagram"
        ? parsed.kind
        : "link";

    /** @type {VideoItem} */
    const item = {
      id: uid(),
      title: meta.title || "مقطع",
      sourceUrl: parsed.pageUrl,
      kind,
      platform: parsed.platform,
      platformId: parsed.id || undefined,
      author: meta.author || "",
      thumbnail: meta.thumbnail || "",
      sizeBytes: 0,
      addedAt: new Date().toISOString(),
      liked: false,
      views: 0,
    };
    addItem(item);
    pushInbox(
      "stream",
      "تم الحفظ في المكتبة",
      `«${item.title}» من ${platformLabel(item)}. يُشغَّل عبر المشغّل الرسمي — الملف يبقى عند المنصة احترامًا لحقوق النشر.`,
      item.id,
    );
    return item;
  }

  async function importLocal(file) {
    if (!file) throw new Error("لم يُختر ملف.");
    const ok = file.type.startsWith("video/") || /\.(mp4|webm|mov|m4v|mkv)$/i.test(file.name);
    if (!ok) throw new Error("اختر ملف فيديو.");
    if (file.size < 1024) throw new Error("الملف صغير جدًا.");
    const sourceUrl = `local:${file.name}:${file.size}`;
    if (findBySource(sourceUrl)) throw new Error("هذا الملف مستورد مسبقًا.");
    const id = uid();
    await idbPut(id, file);
    const title = file.name.replace(/\.[a-z0-9]+$/i, "").replace(/[_-]+/g, " ").trim() || "فيديو";
    /** @type {VideoItem} */
    const item = {
      id,
      title,
      sourceUrl,
      kind: "local",
      platform: "local",
      sizeBytes: file.size,
      addedAt: new Date().toISOString(),
      liked: false,
      views: 0,
    };
    addItem(item);
    pushInbox("imported", "تم الاستيراد", `«${title}» (${formatBytes(file.size)}) نُسخ إلى مكتبتك الخاصة.`, id);
    return item;
  }

  async function downloadHls(url, title, onProgress = () => {}) {
    const requestText = async (src) => {
      const response = await fetch(src);
      if (!response.ok) throw new Error(`تعذّر جلب قائمة HLS (HTTP ${response.status}).`);
      return response.text();
    };
    let playlistUrl = url;
    let playlist = await requestText(playlistUrl);
    if (!playlist.trimStart().startsWith("#EXTM3U")) throw new Error("الرابط لا يحتوي على قائمة HLS صالحة.");

    // Master playlist: select the highest-bandwidth variant.
    if (/#EXT-X-STREAM-INF:/i.test(playlist)) {
      const lines = playlist.split(/\r?\n/);
      let variants = [];
      for (let i = 0; i < lines.length; i++) {
        if (lines[i].startsWith("#EXT-X-STREAM-INF:")) {
          const bandwidth = Number((lines[i].match(/BANDWIDTH=(\d+)/i) || [])[1] || 0);
          const uri = lines.slice(i + 1).find((line) => line.trim() && !line.trim().startsWith("#"));
          if (uri) variants.push({ bandwidth, url: new URL(uri.trim(), playlistUrl).href });
        }
      }
      if (!variants.length) throw new Error("لم أجد مسار فيديو داخل قائمة HLS.");
      playlistUrl = variants.sort((a, b) => b.bandwidth - a.bandwidth)[0].url;
      playlist = await requestText(playlistUrl);
    }

    if (/#EXT-X-KEY:/i.test(playlist) && !/#EXT-X-KEY:.*METHOD=NONE/i.test(playlist)) {
      throw new Error("هذه القائمة مشفّرة. لا يمكن لهذا الإصدار فك DRM أو مفاتيح التشفير؛ استخدم تنزيلًا رسميًا من المصدر.");
    }
    if (/#EXT-X-BYTERANGE:/i.test(playlist)) throw new Error("هذه القائمة تستخدم مقاطع جزئية (BYTERANGE)، وهي غير مدعومة بعد.");

    const lines = playlist.split(/\r?\n/);
    const segments = [];
    let initUrl = null;
    for (const line of lines) {
      const t = line.trim();
      if (t.startsWith("#EXT-X-MAP:")) {
        const match = t.match(/URI="([^"]+)"/i);
        if (match) initUrl = new URL(match[1], playlistUrl).href;
      } else if (t && !t.startsWith("#")) {
        segments.push(new URL(t, playlistUrl).href);
      }
    }
    if (!segments.length) throw new Error("لم يتم العثور على مقاطع فيديو في قائمة HLS.");
    if (segments.length > 2000) throw new Error("القائمة طويلة جدًا للتنزيل داخل المتصفح (أكثر من 2000 مقطع).");

    const parts = [];
    if (initUrl) {
      const initResponse = await fetch(initUrl);
      if (!initResponse.ok) throw new Error("تعذّر تنزيل مقطع التهيئة.");
      parts.push(await initResponse.blob());
    }
    let completed = 0;
    // Fetch in small batches while preserving playlist order.
    for (let start = 0; start < segments.length; start += 4) {
      const batch = segments.slice(start, start + 4);
      const blobs = await Promise.all(batch.map(async (segmentUrl) => {
        let lastError;
        for (let attempt = 0; attempt < 3; attempt++) {
          try {
            const response = await fetch(segmentUrl);
            if (!response.ok) throw new Error(`HTTP ${response.status}`);
            return await response.blob();
          } catch (error) {
            lastError = error;
          }
        }
        throw new Error(`تعذّر تنزيل أحد المقاطع بعد 3 محاولات: ${lastError?.message || "خطأ اتصال"}`);
      }));
      parts.push(...blobs);
      completed += batch.length;
      onProgress(completed, segments.length);
    }
    const mime = initUrl ? "video/mp4" : "video/mp2t";
    const blob = new Blob(parts, { type: mime });
    if (blob.size < 1024) throw new Error("الملف الناتج صغير أو غير مكتمل.");
    const id = uid();
    await idbPut(id, blob);
    const item = {
      id, title: title || "فيديو HLS", sourceUrl: url, kind: "local", platform: "hls",
      sizeBytes: blob.size, addedAt: new Date().toISOString(), liked: false, views: 0,
    };
    addItem(item);
    pushInbox("saved", "اكتمل تنزيل الفيديو", `«${item.title}» — ${segments.length} مقطع تم جمعها في ملف واحد (${formatBytes(blob.size)}).`, id);
    return item;
  }

  async function trySaveDirect(url, title, onProgress = () => {}) {
    const existing = findBySource(url);
    if (existing) return existing;
    if (/\.m3u8(\?|#|$)/i.test(url)) return downloadHls(url, title, onProgress);
    // Attempt client fetch — works only when CORS allows
    try {
      const res = await fetch(url);
      if (!res.ok) throw new Error(`رمز ${res.status}`);
      const type = (res.headers.get("content-type") || "").toLowerCase();
      if (type.includes("html")) throw new Error("الرابط صفحة وليس ملف فيديو.");
      const blob = await res.blob();
      if (blob.size < 1024) throw new Error("الملف صغير جدًا.");
      const id = uid();
      await idbPut(id, blob);
      /** @type {VideoItem} */
      const item = {
        id,
        title: title || "فيديو",
        sourceUrl: url,
        kind: "local",
        platform: "file",
        sizeBytes: blob.size,
        addedAt: new Date().toISOString(),
        liked: false,
        views: 0,
      };
      addItem(item);
      pushInbox("saved", "تم حفظ الملف", `«${item.title}» (${formatBytes(blob.size)}) محفوظ محليًا.`, id);
      return item;
    } catch {
      // Fall back to remote stream entry
      /** @type {VideoItem} */
      const item = {
        id: uid(),
        title: title || "فيديو مباشر",
        sourceUrl: url,
        kind: "remote",
        platform: "file",
        sizeBytes: 0,
        addedAt: new Date().toISOString(),
        liked: false,
        views: 0,
      };
      addItem(item);
      pushInbox(
        "stream",
        "أُضيف للبث",
        `«${item.title}» يُشغَّل من الرابط مباشرة. التحميل المحلي تعذّر بسبب قيود المتصفح (CORS) — جرّب الاستيراد من الجهاز إن حمّلته يدويًا.`,
        item.id,
      );
      return item;
    }
  }

  function removeItem(id) {
    const item = state.items.find((i) => i.id === id);
    if (item?.kind === "local") void idbDel(id);
    state.items = state.items.filter((i) => i.id !== id);
    if (state.playingId === id) closePlayer();
    save();
    render();
  }

  function toggleLike(id) {
    state.items = state.items.map((i) => (i.id === id ? { ...i, liked: !i.liked } : i));
    save();
    render();
  }

  // ─── player ────────────────────────────────────────────────
  async function openPlayer(id) {
    const item = state.items.find((i) => i.id === id);
    if (!item) return;
    state.playingId = id;
    state.watchCount += 1;
    state.items = state.items.map((i) => (i.id === id ? { ...i, views: i.views + 1 } : i));
    save();

    const emb = embedUrl(item);
    const isNative = item.kind === "local" || item.kind === "remote";
    let stageInner = "";
    if (emb) {
      stageInner = `<iframe title="${escapeHtml(item.title)}" src="${emb}" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen referrerpolicy="strict-origin-when-cross-origin"></iframe>`;
    } else if (item.kind === "local") {
      stageInner = ""; // filled below after blob load
    } else if (item.kind === "remote") {
      stageInner = `<video playsinline autoplay src="${escapeHtml(item.sourceUrl)}" style="width:100%;height:100%;object-fit:contain"></video>`;
    } else if (item.kind === "instagram" || item.kind === "link") {
      stageInner = `<div style="display:grid;place-items:center;height:100%;padding:1.5rem;text-align:center;background:var(--surface);color:var(--fg)">
        <div>
          <p style="font-weight:800;margin:0 0 .5rem">يُفتح من الرابط الأصلي</p>
          <p class="muted" style="margin:0 0 1rem">هذه المنصة لا توفّر تضمينًا حرًا داخل التطبيق. الرابط محفوظ في مكتبتك.</p>
          <a class="btn btn-primary" style="width:auto;display:inline-flex" href="${escapeHtml(item.sourceUrl)}" target="_blank" rel="noopener noreferrer">فتح المصدر</a>
        </div>
      </div>`;
    }

    const seekHint = isNative
      ? `<div class="seek-hint muted">ضغطتان يمين = +10ث · ضغطتان يسار = −10ث · اسحب الشريط للتنقل</div>`
      : "";

    playerEl.innerHTML = `
      <div class="player-inner">
        <div class="player-top">
          <button type="button" class="icon-btn" data-close aria-label="إغلاق">✕</button>
          <div class="title">${escapeHtml(item.title)}</div>
          <button type="button" class="icon-btn ${item.liked ? "liked" : ""}" data-like aria-label="إعجاب">♥</button>
        </div>
        <div class="player-stage ${isNative ? "native-stage" : ""}" id="player-stage">${stageInner}</div>
        <div class="player-foot">
          ${item.author ? `<div class="muted">${escapeHtml(item.author)}</div>` : ""}
          ${seekHint}
          <div class="muted" style="font-size:.8rem;line-height:1.55">
            ${
              emb
                ? "التشغيل عبر المشغّل الرسمي للمنصة. التحكم بالتقديم/الترجيع من داخل مشغّل المنصة."
                : item.kind === "local"
                  ? "ملف محفوظ على جهازك داخل TikJil."
                  : "محفوظ في مكتبتك الخاصة."
            }
          </div>
        </div>
      </div>`;
    playerEl.classList.remove("hidden");

    playerEl.querySelector("[data-close]")?.addEventListener("click", closePlayer);
    playerEl.querySelector("[data-like]")?.addEventListener("click", () => {
      toggleLike(item.id);
      openPlayer(item.id);
    });

    const stageHost = playerEl.querySelector("#player-stage");

    if (item.kind === "local") {
      const blob = await idbGet(item.id);
      if (stageHost && blob) {
        const url = URL.createObjectURL(blob);
        const video = document.createElement("video");
        video.playsInline = true;
        video.autoplay = true;
        video.loop = state.settings.loop;
        video.src = url;
        video.style.width = "100%";
        video.style.height = "100%";
        video.style.objectFit = "contain";
        stageHost.appendChild(video);
        video.addEventListener("emptied", () => URL.revokeObjectURL(url), { once: true });
        wireNativeVideoControls(video, stageHost);
      } else if (stageHost) {
        stageHost.innerHTML = `<p class="muted" style="padding:2rem;text-align:center">تعذّر قراءة الملف المحلي.</p>`;
      }
    } else if (item.kind === "remote" && stageHost) {
      const video = stageHost.querySelector("video");
      if (video) {
        video.loop = state.settings.loop;
        wireNativeVideoControls(video, stageHost);
      }
    }
  }

  function closePlayer() {
    state.playingId = null;
    playerEl.classList.add("hidden");
    playerEl.innerHTML = "";
  }

  // ─── recover flow ──────────────────────────────────────────
  async function recoverUrl(raw, onProgress = () => {}) {
    const parsed = parsePlatform(raw);
    if (!parsed) throw new Error("الرابط غير صالح. يجب أن يبدأ بـ http:// أو https://");

    if (parsed.note && !parsed.id && parsed.kind === "link" && parsed.platform !== "web") {
      throw new Error(parsed.note);
    }

    if (parsed.kind === "remote") {
      const meta = await resolveMeta(parsed);
      return { mode: "file", parsed, meta, item: await trySaveDirect(parsed.pageUrl, meta.title, onProgress) };
    }

    if (parsed.kind === "youtube" || parsed.kind === "tiktok" || parsed.kind === "vimeo" || parsed.kind === "instagram") {
      if (!parsed.id && parsed.kind !== "instagram") throw new Error(parsed.note || "حدّد رابط المقطع.");
      const meta = await resolveMeta(parsed);
      const item = await savePlatformClip(parsed, meta);
      return { mode: "platform", parsed, meta, item };
    }

    // Generic web link — save as bookmark entry
    const meta = await resolveMeta(parsed);
    meta.title = meta.title === "مقطع" ? "رابط محفوظ" : meta.title;
    const item = await savePlatformClip({ ...parsed, kind: "link" }, meta);
    return { mode: "link", parsed, meta, item };
  }

  // ─── views ─────────────────────────────────────────────────
  function renderHome() {
    const { layout } = state.settings;
    const items = state.items;

    let body = "";
    if (!items.length) {
      body = `
        <div class="empty card">
          ${markIcon(true)}
          <h2 class="h2">مكتبتك فاضية</h2>
          <p class="muted">الصق رابط يوتيوب أو تيك توك أو فيميو في «استرداد»، أو استورد فيديو من جهازك. المقاطع تُحفظ هنا للتشغيل السريع.</p>
          <button type="button" class="btn btn-primary mt" data-go="recover">استرداد رابط</button>
          <button type="button" class="btn btn-ghost mt-sm" data-go="browser">فتح المتصفح</button>
        </div>`;
    } else if (layout === "grid") {
      body = `<div class="grid">${items
        .map(
          (i) => `
        <button type="button" class="grid-card" data-play="${i.id}">
          ${i.thumbnail ? `<img class="thumb" src="${escapeHtml(i.thumbnail)}" alt="" />` : `<div class="thumb ph">▶</div>`}
          <div class="pad">${escapeHtml(i.title)}</div>
        </button>`,
        )
        .join("")}</div>`;
    } else if (layout === "reels") {
      body = `<div class="reels">${items
        .map(
          (i) => `
        <div class="reel" data-play="${i.id}">
          ${
            i.thumbnail
              ? `<img src="${escapeHtml(i.thumbnail)}" alt="" />`
              : i.kind === "local" || i.kind === "remote"
                ? `<div style="display:grid;place-items:center;height:100%;color:var(--primary);font-size:2rem">▶</div>`
                : `<div style="display:grid;place-items:center;height:100%;color:var(--muted)">لا معاينة</div>`
          }
          <div class="shade">
            <div style="font-weight:800">${escapeHtml(i.title)}</div>
            <div class="muted" style="font-size:.75rem;margin-top:.25rem">${platformLabel(i)}</div>
          </div>
          <div class="actions">
            <button type="button" class="icon-btn ${i.liked ? "liked" : ""}" data-like="${i.id}">♥</button>
            <button type="button" class="icon-btn" data-del="${i.id}">🗑</button>
          </div>
        </div>`,
        )
        .join("")}</div>`;
    } else {
      body = `<div class="video-list">${items
        .map(
          (i) => `
        <div class="video-row">
          <button type="button" data-play="${i.id}" style="display:contents">
            ${i.thumbnail ? `<img class="thumb" src="${escapeHtml(i.thumbnail)}" alt="" />` : `<div class="thumb ph">▶</div>`}
            <div style="flex:1;min-width:0;text-align:start">
              <p class="title">${escapeHtml(i.title)}</p>
              <div class="meta">${platformLabel(i)}${i.author ? " · " + escapeHtml(i.author) : ""}${i.sizeBytes ? " · " + formatBytes(i.sizeBytes) : ""}</div>
            </div>
          </button>
          <button type="button" class="icon-btn" data-del="${i.id}" aria-label="حذف">🗑</button>
        </div>`,
        )
        .join("")}</div>`;
    }

    view.innerHTML = `
      <div class="between mb">
        <div class="row">${markIcon()}<h1 class="h1">TikJil</h1></div>
        <div class="seg" style="grid-template-columns:repeat(3,auto);width:auto">
          <button type="button" data-layout="list" class="${layout === "list" ? "on" : ""}">قائمة</button>
          <button type="button" data-layout="grid" class="${layout === "grid" ? "on" : ""}">شبكة</button>
          <button type="button" data-layout="reels" class="${layout === "reels" ? "on" : ""}">ريلز</button>
        </div>
      </div>
      ${body}`;

    view.querySelectorAll("[data-go]").forEach((b) =>
      b.addEventListener("click", () => {
        state.tab = b.getAttribute("data-go");
        syncNav();
        render();
      }),
    );
    view.querySelectorAll("[data-layout]").forEach((b) =>
      b.addEventListener("click", () => {
        state.settings.layout = b.getAttribute("data-layout");
        save();
        render();
      }),
    );
    view.querySelectorAll("[data-play]").forEach((b) =>
      b.addEventListener("click", (e) => {
        e.stopPropagation();
        openPlayer(b.getAttribute("data-play") || b.closest("[data-play]")?.getAttribute("data-play"));
      }),
    );
    view.querySelectorAll("[data-del]").forEach((b) =>
      b.addEventListener("click", (e) => {
        e.stopPropagation();
        if (confirm("حذف من المكتبة؟")) removeItem(b.getAttribute("data-del"));
      }),
    );
    view.querySelectorAll("[data-like]").forEach((b) =>
      b.addEventListener("click", (e) => {
        e.stopPropagation();
        toggleLike(b.getAttribute("data-like"));
      }),
    );
  }

  function renderRecover() {
    view.innerHTML = `
      <h1 class="h1">استرداد</h1>
      <p class="muted mt-sm">الصق رابط منصة أو ملف مباشر أو قائمة HLS بصيغة M3U8. يمكن تنزيل قوائم HLS غير المشفّرة وجمع مقاطعها بالترتيب في ملف واحد إذا سمح الخادم بالوصول (CORS).</p>
      <div class="notice mt">خاص بك فقط — لا نشر. المشاهدة الشخصية عبر المشغّلات الرسمية مع احترام حقوق النشر.</div>
      <div class="field mt">
        <input id="url" dir="ltr" placeholder="https://youtu.be/…" value="${SAMPLE_YT}" />
        <button type="button" class="btn btn-sm btn-ghost" id="paste" style="width:auto">لصق</button>
      </div>
      <div class="row mt-sm" style="flex-wrap:wrap;gap:.4rem">
        <button type="button" class="chip" data-sample="${SAMPLE_YT}">رابط يوتيوب</button>
        <button type="button" class="chip" data-sample="https://www.tiktok.com/">تيك توك (الصق مقطعًا)</button>
      </div>
      <button type="button" class="btn btn-primary mt" id="go">فحص وحفظ في المكتبة</button>
      <div id="status" class="mt-sm"></div>
      <div id="result" class="mt"></div>
      <div class="card soft mt">
        <h2 class="h2">استيراد من جهازك</h2>
        <p class="muted mt-sm">أي فيديو حمّلته بنفسك يُنسخ إلى مخزن TikJil الخاص في هذا المتصفح.</p>
        <input type="file" id="file" accept="video/*" hidden />
        <button type="button" class="btn btn-ghost mt" id="pick">اختيار فيديو</button>
      </div>`;

    const urlInput = view.querySelector("#url");
    const status = view.querySelector("#status");
    const result = view.querySelector("#result");

    view.querySelector("#paste")?.addEventListener("click", async () => {
      try {
        const t = await navigator.clipboard.readText();
        if (t.trim()) urlInput.value = t.trim();
      } catch {
        status.innerHTML = `<p class="err">تعذّر قراءة الحافظة — الصق يدويًا.</p>`;
      }
    });

    view.querySelectorAll("[data-sample]").forEach((b) =>
      b.addEventListener("click", () => {
        urlInput.value = b.getAttribute("data-sample") || "";
      }),
    );

    view.querySelector("#go")?.addEventListener("click", async () => {
      status.innerHTML = `<p class="muted">جارٍ الفحص…</p>`;
      result.innerHTML = "";
      try {
        const out = await recoverUrl(urlInput.value, (done, total) => {
          status.innerHTML = `<p class="muted">تنزيل ودمج المقاطع: ${done} من ${total} (${Math.round(done / total * 100)}٪)</p>`;
        });
        status.innerHTML = `<p class="ok">تم الحفظ في المكتبة.</p>`;
        result.innerHTML = renderResultCard(out.item, out.mode);
        bindResultActions(result);
        toast("صار في مكتبتك");
        updateBadge();
      } catch (e) {
        status.innerHTML = `<p class="err">${escapeHtml(e instanceof Error ? e.message : "تعذّر الاسترداد")}</p>`;
      }
    });

    view.querySelector("#pick")?.addEventListener("click", () => view.querySelector("#file")?.click());
    view.querySelector("#file")?.addEventListener("change", async (e) => {
      const file = e.target.files?.[0];
      e.target.value = "";
      if (!file) return;
      try {
        const item = await importLocal(file);
        status.innerHTML = `<p class="ok">تم استيراد «${escapeHtml(item.title)}»</p>`;
        toast("تم الاستيراد");
        updateBadge();
      } catch (err) {
        status.innerHTML = `<p class="err">${escapeHtml(err instanceof Error ? err.message : "فشل الاستيراد")}</p>`;
      }
    });
  }

  function renderResultCard(item, mode) {
    return `
      <article class="result-card">
        ${item.thumbnail ? `<img class="cover" src="${escapeHtml(item.thumbnail)}" alt="" />` : ""}
        <div class="body">
          <span class="pill">${platformLabel(item)}</span>
          <h3 class="h2">${escapeHtml(item.title)}</h3>
          ${item.author ? `<p class="muted">${escapeHtml(item.author)}</p>` : ""}
          <p class="muted" style="font-size:.8rem">
            ${
              mode === "platform"
                ? "محفوظ للتشغيل عبر المشغّل الرسمي. الملف يبقى عند المنصة."
                : mode === "file"
                  ? "ملف مباشر — حُفظ محليًا إن سمح المتصفح، وإلا كبث."
                  : "رابط محفوظ في مكتبتك."
            }
          </p>
          <button type="button" class="btn btn-primary" data-play="${item.id}">تشغيل</button>
          ${item.kind === "local" ? `<button type="button" class="btn btn-ghost" data-export="${item.id}">حفظ الملف على الجهاز</button>` : ""}
          <button type="button" class="btn btn-ghost" data-go="home">عرض المكتبة</button>
        </div>
      </article>`;
  }

  function bindResultActions(root) {
    root.querySelector("[data-export]")?.addEventListener("click", async (e) => {
      const id = e.currentTarget.getAttribute("data-export");
      try {
        const blob = await idbGet(id);
        if (!blob) throw new Error("الملف غير موجود في التخزين المحلي.");
        const objectUrl = URL.createObjectURL(blob);
        const a = document.createElement("a");
        a.href = objectUrl;
        a.download = `${(state.items.find((item) => item.id === id)?.title || "video").replace(/[\\/:*?"<>|]+/g, "_")}.${blob.type === "video/mp4" ? "mp4" : blob.type === "video/mp2t" ? "ts" : "mp4"}`;
        a.click();
        setTimeout(() => URL.revokeObjectURL(objectUrl), 1500);
      } catch (error) {
        toast(error instanceof Error ? error.message : "تعذّر تصدير الملف");
      }
    });
    root.querySelector("[data-play]")?.addEventListener("click", (e) => {
      openPlayer(e.currentTarget.getAttribute("data-play"));
    });
    root.querySelector("[data-go]")?.addEventListener("click", () => {
      state.tab = "home";
      syncNav();
      render();
    });
  }

  function renderBrowser() {
    view.innerHTML = `
      <h1 class="h1">المتصفح</h1>
      <p class="muted mt-sm">الصق رابط مقطع أو ابحث بالعنوان. المتصفح هنا مخصّص لاسترداد الفيديو لمكتبتك — بدون سجل دائم.</p>
      <div class="field mt">
        <input id="q" dir="ltr" placeholder="رابط أو كلمة" />
        <button type="button" class="btn btn-sm btn-primary" id="open" style="width:auto">فتح</button>
      </div>
      <div class="stack mt gap-sm">
        <div class="card soft">
          <div style="font-weight:800">يوتيوب / تيك توك / فيميو</div>
          <p class="muted mt-sm" style="font-size:.8rem">نحفظ المقطع في المكتبة ونشغّله بالمشغّل الرسمي. لا استخراج للملف.</p>
        </div>
        <div class="card soft">
          <div style="font-weight:800">ملفات مباشرة وقوائم HLS</div>
          <p class="muted mt-sm" style="font-size:.8rem">يدعم تنزيل ملفات الفيديو المباشرة وقوائم M3U8 غير المشفّرة، مع جمع المقاطع بالترتيب. يلزم أن يسمح الخادم بالوصول من المتصفح.</p>
        </div>
        <div class="card soft">
          <div style="font-weight:800">بدون سجل</div>
          <p class="muted mt-sm" style="font-size:.8rem">ما يُكتب هنا يبقى على جهازك في هذا المتصفح فقط.</p>
        </div>
      </div>
      <button type="button" class="btn btn-primary mt" data-fill="${SAMPLE_YT}">تجربة رابط يوتيوب</button>
      <div id="bstatus" class="mt-sm"></div>
      <div id="bresult" class="mt"></div>`;

    const q = view.querySelector("#q");
    const st = view.querySelector("#bstatus");
    const res = view.querySelector("#bresult");

    async function run(val) {
      const text = (val ?? q.value).trim();
      if (!text) return;
      q.value = text;
      st.innerHTML = `<p class="muted">جارٍ…</p>`;
      res.innerHTML = "";
      // If it looks like URL → recover; else treat as search hint
      if (/^https?:\/\//i.test(text) || /^[\w.-]+\.[a-z]{2,}/i.test(text)) {
        try {
          const out = await recoverUrl(text, (done, total) => {
            st.innerHTML = `<p class="muted">تنزيل ودمج المقاطع: ${done} من ${total} (${Math.round(done / total * 100)}٪)</p>`;
          });
          st.innerHTML = `<p class="ok">تم.</p>`;
          res.innerHTML = renderResultCard(out.item, out.mode);
          bindResultActions(res);
          toast("في المكتبة");
          updateBadge();
        } catch (e) {
          st.innerHTML = `<p class="err">${escapeHtml(e instanceof Error ? e.message : "تعذّر")}</p>`;
        }
      } else {
        st.innerHTML = `<p class="muted">للبحث العام افتح الموقع في متصفحك ثم الصق رابط المقطع هنا. TikJil يركّز على استرداد الرابط لمكتبتك.</p>`;
        res.innerHTML = `<a class="btn btn-tonal" href="https://duckduckgo.com/?q=${encodeURIComponent(text)}" target="_blank" rel="noopener">بحث عن «${escapeHtml(text)}»</a>`;
      }
    }

    view.querySelector("#open")?.addEventListener("click", () => run());
    q?.addEventListener("keydown", (e) => {
      if (e.key === "Enter") run();
    });
    view.querySelector("[data-fill]")?.addEventListener("click", () => {
      q.value = SAMPLE_YT;
      run(SAMPLE_YT);
    });
  }

  function renderInbox() {
    const list = state.inbox;
    view.innerHTML = `
      <h1 class="h1">الوارد</h1>
      <p class="muted mt-sm">سجل الحفظ والاستيراد على هذا الجهاز فقط.</p>
      ${
        !list.length
          ? `<p class="muted mt" style="text-align:center">الوارد فاضي.</p>`
          : `<div class="stack mt">${list
              .map(
                (m) => `
            <article class="inbox-item ${m.read ? "" : "unread"}" data-id="${m.id}" data-vid="${m.videoId || ""}">
              <div class="between">
                <h3>${escapeHtml(m.title)}</h3>
                <span class="pill">${escapeHtml(m.kind)}</span>
              </div>
              <p>${escapeHtml(m.body)}</p>
              <div class="row mt-sm">
                <button type="button" class="btn btn-sm btn-ghost" data-del-msg="${m.id}">حذف</button>
              </div>
            </article>`,
              )
              .join("")}</div>`
      }`;

    view.querySelectorAll(".inbox-item").forEach((el) =>
      el.addEventListener("click", (e) => {
        if (e.target.closest("[data-del-msg]")) return;
        const id = el.getAttribute("data-id");
        const vid = el.getAttribute("data-vid");
        state.inbox = state.inbox.map((m) => (m.id === id ? { ...m, read: true } : m));
        save();
        updateBadge();
        if (vid) openPlayer(vid);
        else render();
      }),
    );
    view.querySelectorAll("[data-del-msg]").forEach((b) =>
      b.addEventListener("click", (e) => {
        e.stopPropagation();
        state.inbox = state.inbox.filter((m) => m.id !== b.getAttribute("data-del-msg"));
        save();
        updateBadge();
        render();
      }),
    );
  }

  function renderProfile() {
    const likes = state.items.filter((i) => i.liked).length;
    const bytes = state.items.reduce((s, i) => s + (i.kind === "local" ? i.sizeBytes : 0), 0);
    const initial = (state.profile.name || "؟").trim().slice(0, 1);
    view.innerHTML = `
      <div class="row">
        <div style="width:3.5rem;height:3.5rem;border-radius:999px;background:var(--primary);color:var(--bg);display:grid;place-items:center;font-weight:800;font-size:1.25rem">${escapeHtml(initial)}</div>
        <div>
          <h1 class="h1" style="font-size:1.25rem">${escapeHtml(state.profile.name)}</h1>
          <p class="muted" style="margin:0">${escapeHtml(state.profile.bio)}</p>
        </div>
      </div>
      <div class="stats mt">
        <div class="stat"><b>${state.items.length}</b><span>فيديو</span></div>
        <div class="stat"><b>${likes}</b><span>إعجاب</span></div>
        <div class="stat"><b>${state.watchCount}</b><span>مشاهدة</span></div>
        <div class="stat"><b>${formatBytes(bytes)}</b><span>مساحة</span></div>
      </div>
      <div class="notice mt">هذا التطبيق خاص بجهازك/متصفحك. لا حساب سحابي ولا نشر تلقائي.</div>
      <div class="card mt">
        <h2 class="h2">تعديل الاسم</h2>
        <div class="field mt-sm"><input id="pname" dir="rtl" value="${escapeHtml(state.profile.name)}" /></div>
        <div class="field mt-sm"><input id="pbio" dir="rtl" value="${escapeHtml(state.profile.bio)}" /></div>
        <button type="button" class="btn btn-primary mt" id="psave">حفظ</button>
      </div>
      <div class="card mt">
        <h2 class="h2">فيديوهاتي</h2>
        <div class="video-list mt-sm">
          ${
            state.items.length
              ? state.items
                  .slice(0, 12)
                  .map(
                    (i) => `
            <button type="button" class="video-row" data-play="${i.id}">
              ${i.thumbnail ? `<img class="thumb" src="${escapeHtml(i.thumbnail)}" alt="" />` : `<div class="thumb ph">▶</div>`}
              <div style="min-width:0">
                <p class="title">${escapeHtml(i.title)}</p>
                <div class="meta">${platformLabel(i)}</div>
              </div>
            </button>`,
                  )
                  .join("")
              : `<p class="muted">لا شيء بعد.</p>`
          }
        </div>
      </div>`;

    view.querySelector("#psave")?.addEventListener("click", () => {
      state.profile.name = view.querySelector("#pname").value.trim() || "أنا";
      state.profile.bio = view.querySelector("#pbio").value.trim();
      save();
      toast("تم الحفظ");
      render();
    });
    view.querySelectorAll("[data-play]").forEach((b) =>
      b.addEventListener("click", () => openPlayer(b.getAttribute("data-play"))),
    );
  }

  function render() {
    if (state.tab === "home") renderHome();
    else if (state.tab === "browser") renderBrowser();
    else if (state.tab === "recover") renderRecover();
    else if (state.tab === "inbox") renderInbox();
    else renderProfile();
  }

  function syncNav() {
    document.querySelectorAll(".nav-btn").forEach((b) => {
      b.classList.toggle("active", b.getAttribute("data-tab") === state.tab);
    });
  }

  // ─── boot ──────────────────────────────────────────────────
  document.querySelectorAll(".nav-btn").forEach((b) =>
    b.addEventListener("click", () => {
      state.tab = b.getAttribute("data-tab");
      syncNav();
      render();
    }),
  );

  window.addEventListener("online", () => offlineEl.classList.add("hidden"));
  window.addEventListener("offline", () => offlineEl.classList.remove("hidden"));
  if (!navigator.onLine) offlineEl.classList.remove("hidden");

  document.addEventListener("keydown", (e) => {
    if (e.key === "Escape") closePlayer();
  });

  load();
  ensureSeed();
  updateBadge();
  render();
})();
